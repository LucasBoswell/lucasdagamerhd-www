# 8L-Train-Project
This is a Factorio mod that changes train locomotives and wagons to be exactly 8 units long.

It currently supports FARL, RailTanker, Bob's mods, More Locomotives, Color Coding, Factorio Extended, and Shuttle Train.